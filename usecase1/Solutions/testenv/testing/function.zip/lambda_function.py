def lambda_handler(event, context):
  for record in event['Records']:
    bucket = record['s3']['bucket']['name']
  print(bucket)